#include <stdio.h>

void myprintf(char* str)
{
  printf("HERE IT IS:\n");
  printf("%s", str);
}

