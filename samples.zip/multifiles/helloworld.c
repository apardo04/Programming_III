extern void myprintf(char* str);

int main()
{
  myprintf("Hello, world!\n");
  return 0;
}

