/*
 * The first C program.
 *
 * Compile (and link) the code using: 
 *    % gcc helloworld.c -o helloworld
 * Run it as:
 *    % ./helloworld
 */

#include <stdio.h>

int main()
{
  printf("Hello World TO ALL!\n");
  return 0;
}
