#include <stdio.h>

void myprintf(char* str)
{
  printf("NEW NEW NEW!!! MYPRINTF: %s\n", str);
}
