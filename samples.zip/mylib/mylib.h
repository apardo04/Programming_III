#ifndef _MYLIB_H_
#define _MYLIB_H_

extern void myprintf(char*);
extern int myatoi(char*);

#endif /*_MYLIB_H_*/
