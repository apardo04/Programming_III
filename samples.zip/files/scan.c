#include <stdio.h>

int main(int argc, char* argv[])
{
  int x; float y;
  scanf("%d %f\n", &x, &y);
  printf("x=%d y=%f\n", x, y);
  return 0;
}

